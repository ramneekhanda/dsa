import{a as t}from"../chunks/entry.HReeRPck.js";export{t as start};
