import{a as t}from"../chunks/entry.CIoss4s0.js";export{t as start};
