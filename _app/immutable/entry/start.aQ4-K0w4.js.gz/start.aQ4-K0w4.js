import{a as t}from"../chunks/entry.YRAuEdbU.js";export{t as start};
