import{a as t}from"../chunks/entry.BCdG_m_L.js";export{t as start};
