import{a as t}from"../chunks/entry.BwphaYXF.js";export{t as start};
