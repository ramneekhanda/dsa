import{a as t}from"../chunks/entry.UdurCY79.js";export{t as start};
