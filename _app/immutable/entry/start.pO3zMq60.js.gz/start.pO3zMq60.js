import{a as t}from"../chunks/entry.COZc3wzg.js";export{t as start};
