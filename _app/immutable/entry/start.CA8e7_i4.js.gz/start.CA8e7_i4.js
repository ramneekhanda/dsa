import{a as t}from"../chunks/entry.CKxIS3cW.js";export{t as start};
