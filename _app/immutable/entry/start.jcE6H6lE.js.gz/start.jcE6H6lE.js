import{a as t}from"../chunks/entry.BQRDAAPr.js";export{t as start};
