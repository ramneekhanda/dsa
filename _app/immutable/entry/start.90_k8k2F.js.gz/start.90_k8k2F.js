import{a as t}from"../chunks/entry.CITb2wg1.js";export{t as start};
