import{a as t}from"../chunks/entry.BHJTIos9.js";export{t as start};
